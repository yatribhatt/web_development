<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if both files were uploaded
    if (isset($_FILES['identity-doc1']) && isset($_FILES['identity-doc2'])) {
        
        // Handle Document 1
        $file1 = $_FILES['identity-doc1'];
        $file1_name = basename($file1['name']);
        $upload_dir = 'uploads/';
        $upload_path1 = $upload_dir . $file1_name;

        if (move_uploaded_file($file1['tmp_name'], $upload_path1)) {
            echo "Document 1 uploaded successfully.<br>";
        } else {
            echo "Failed to upload Document 1.<br>";
        }

        // Handle Document 2
        $file2 = $_FILES['identity-doc2'];
        $file2_name = basename($file2['name']);
        $upload_path2 = $upload_dir . $file2_name;

        if (move_uploaded_file($file2['tmp_name'], $upload_path2)) {
            echo "Document 2 uploaded successfully.<br>";
        } else {
            echo "Failed to upload Document 2.<br>";
        }
    } else {
        echo "Both documents are required.";
    }
}
?>
